/*
 Copyright (C) 2016 Apple Inc. All Rights Reserved.
 See LICENSE.txt for this sample’s licensing information
 
 Abstract:
 App delegate (NSApplicationDelegate)
 */

@import Cocoa;

@interface AppDelegate : NSObject <NSApplicationDelegate>

@end
