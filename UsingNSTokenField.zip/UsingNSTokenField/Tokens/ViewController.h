/*
 Copyright (C) 2016 Apple Inc. All Rights Reserved.
 See LICENSE.txt for this sample’s licensing information
 
 Abstract:
 Main view controller for this sample.
 */

@import Cocoa;

@interface ViewController : NSViewController

@end
