/*
 Copyright (C) 2016 Apple Inc. All Rights Reserved.
 See LICENSE.txt for this sample’s licensing information
 
 Abstract:
 Main source file for this sample.
 */

@import Cocoa;

int main(int argc, char *argv[])
{
    return NSApplicationMain(argc, (const char **)argv);
}
