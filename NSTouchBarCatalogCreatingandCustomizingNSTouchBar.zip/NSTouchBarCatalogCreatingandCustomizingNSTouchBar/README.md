# NSTouchBar Catalog: Creating and Customizing NSTouchBar

NSTouchBar Catalog demonstrates how to use the NSTouchBar class for macOS. Refer to this sample if you are looking for specific ways to create NSTouchBar instances in a variety of situations. Among these cases includes the use of the NSScrubber control.

## Requirements

### Build

Xcode 8.2 or later; macOS 10.12.2 SDK or later

### Runtime

macOS 10.12.1 or later

Copyright (C) 2016 Apple Inc. All rights reserved.
