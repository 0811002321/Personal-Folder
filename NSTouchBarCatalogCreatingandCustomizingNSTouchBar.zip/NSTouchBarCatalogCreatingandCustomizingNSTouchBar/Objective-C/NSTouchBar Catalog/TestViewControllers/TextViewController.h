/*
 Copyright (C) 2016 Apple Inc. All Rights Reserved.
 See LICENSE.txt for this sample’s licensing information
 
 Abstract:
 View controller responsible for NSTouchBarItem instances used with an NSTextView.
 */

#import <Cocoa/Cocoa.h>

@interface TextViewController : NSViewController

@end
