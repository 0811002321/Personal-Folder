/*
 Copyright (C) 2016 Apple Inc. All Rights Reserved.
 See LICENSE.txt for this sample’s licensing information
 
 Abstract:
 View controller responsible for showing grouped (NSGroupTouchBarItem) NSTouchBarItem instances.
 */

#import "GroupViewController.h"

@implementation GroupViewController

@end
