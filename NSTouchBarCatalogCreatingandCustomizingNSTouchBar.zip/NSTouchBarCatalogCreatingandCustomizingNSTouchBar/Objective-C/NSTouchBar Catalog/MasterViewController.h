/*
 Copyright (C) 2016 Apple Inc. All Rights Reserved.
 See LICENSE.txt for this sample’s licensing information
 
 Abstract:
 The master view controller giving access to all test cases in this sample.
 */

#import <Cocoa/Cocoa.h>

@interface MasterViewController : NSViewController

@end

