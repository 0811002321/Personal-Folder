### Project links

Resource                 | Link
-------------------------|---------------------------------------------------
Website                  | http://www.hammerspoon.org/
GitHub page              | https://github.com/Hammerspoon/hammerspoon/
Getting Started Guide    | http://www.hammerspoon.org/go/
IRC channel              | #hammerspoon on freenode
Mailing list             | https://groups.google.com/forum/#!forum/hammerspoon/
LuaSkin API docs         | http://www.hammerspoon.org/docs/LuaSkin/
