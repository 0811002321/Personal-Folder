//
//  HSChooserRootView.m
//  Hammerspoon
//
//  Created by Chris Jones on 26/10/2016.
//  Copyright © 2016 Hammerspoon. All rights reserved.
//

#import "HSChooserRootView.h"

@implementation HSChooserRootView

- (BOOL)allowsVibrancy {
    return YES;
}

@end
