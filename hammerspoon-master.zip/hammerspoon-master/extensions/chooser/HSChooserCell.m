//
//  HSChooserCell.m
//  Hammerspoon
//
//  Created by Chris Jones on 29/12/2015.
//  Copyright © 2015 Hammerspoon. All rights reserved.
//

#import "HSChooserCell.h"

@implementation HSChooserCell

- (BOOL)allowsVibrancy {
    return YES;
}

@end
