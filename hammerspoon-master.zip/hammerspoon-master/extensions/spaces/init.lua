local spaces = {}

spaces.watcher = require "hs.spaces.watcher"

return spaces