require "test_javascript"
require "test_applescript"
