Hammerspoon is based on Mjolnir by Steven Degutis, which is based on Hydra by Steven Degutis.

The extensions included in Hammerspoon were written by:
 * Steven Degutis
 * Aaron Magill
 * Chris Jones
 * Peter van Dijk
 * Linell Bonnette
 * Kepler Project
 * Enrique García Cota
 * Szymon Kaliski
 * Brian Gilbert
 * Tristan Hume
 * Tyler Mandry
 * Alexander Yakushev
 * Jake Heinz
 * Till Klocke
 * Markus Engelbrecht

The Hammerspon icon was provided by Juerd Waalboer
