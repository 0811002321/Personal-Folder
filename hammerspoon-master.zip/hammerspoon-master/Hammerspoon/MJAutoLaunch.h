#import <CoreServices/CoreServices.h>

BOOL MJAutoLaunchGet(void);
void MJAutoLaunchSet(BOOL opensAtLogin);
