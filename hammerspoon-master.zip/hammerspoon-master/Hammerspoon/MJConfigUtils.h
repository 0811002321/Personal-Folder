#import <Foundation/Foundation.h>

NSString* MJConfigDir(void);
NSString* MJConfigFileFullPath(void);
