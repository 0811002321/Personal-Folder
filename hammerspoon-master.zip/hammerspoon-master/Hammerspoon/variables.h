#define MJShowDockIconKey            @"MJShowDockIconKey"
#define MJShowMenuIconKey            @"MJShowMenuIconKey"
#define MJKeepConsoleOnTopKey        @"MJKeepConsoleOnTopKey"
#define MJHasRunAlreadyKey           @"MJHasRunAlreadyKey"
#define HSAutoLoadExtensions         @"HSAutoLoadExtensions"
#define HSUploadCrashDataKey         @"HSUploadCrashData"

extern NSString* MJConfigFile;