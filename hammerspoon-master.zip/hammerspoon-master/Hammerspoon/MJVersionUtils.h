#import <Foundation/Foundation.h>

int MJVersionFromThisApp(void);
int MJVersionFromString(NSString* str);
