#import <Foundation/Foundation.h>

void MJDockIconSetup(void);
BOOL MJDockIconVisible(void);
void MJDockIconSetVisible(BOOL visible);
