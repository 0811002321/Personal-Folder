//
//  variables.m
//  Hammerspoon
//
//  Created by Peter van Dijk on 28/10/14.
//  Copyright (c) 2014 Hammerspoon. All rights reserved.
//

NSString* MJConfigFile = @"~/.hammerspoon/init.lua";
