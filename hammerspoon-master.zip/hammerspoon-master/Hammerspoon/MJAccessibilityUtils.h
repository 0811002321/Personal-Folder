#import <Foundation/Foundation.h>

BOOL MJAccessibilityIsEnabled(void);
void MJAccessibilityOpenPanel(void);
