#import <Foundation/Foundation.h>

void MJMenuIconSetup(NSMenu* menu);
BOOL MJMenuIconVisible(void);
void MJMenuIconSetVisible(BOOL visible);
