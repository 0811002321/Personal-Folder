#import <Foundation/Foundation.h>

BOOL MJEnsureDirectoryExists(NSString* dir);
