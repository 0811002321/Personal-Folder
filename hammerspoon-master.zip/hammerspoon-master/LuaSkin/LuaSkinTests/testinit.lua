-- Note: This file is loaded by lsunit.lua

print("-- LuaSkinTests testinit.lua loaded")