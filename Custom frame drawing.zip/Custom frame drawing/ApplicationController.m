//
//  ApplicationController.m
//  Custom frame drawing
//
//  Created by Patrick Geiller on 13/03/09.
//  Copyright 2009 __MyCompanyName__. All rights reserved.
//

#import "ApplicationController.h"

#import <objc/runtime.h>


@interface ApplicationController(ShutUpXcode)
- (float)roundedCornerRadius;
- (void)drawRectOriginal:(NSRect)rect;
- (NSWindow*)window;
@end

@implementation ApplicationController


BOOL	isDrawingCustomFrame = YES;

- (void)applicationDidFinishLaunching:(id)notif
{
	id window = [[[NSApplication sharedApplication] windows] objectAtIndex:0];
	NSLog(@"done %@", window);

	
	// Get window's frame view class
	id class = [[[window contentView] superview] class];
	NSLog(@"class=%@", class);

	
	// Exchange draw rect
	Method m0 = class_getInstanceMethod([self class], @selector(drawRect:));
	class_addMethod(class, @selector(drawRectOriginal:), method_getImplementation(m0), method_getTypeEncoding(m0));
	
	Method m1 = class_getInstanceMethod(class, @selector(drawRect:));
	Method m2 = class_getInstanceMethod(class, @selector(drawRectOriginal:));
	
	method_exchangeImplementations(m1, m2);
}

- (IBAction)toggleDrawing:(id)sender
{
	NSLog(@"toggle drawing");
	isDrawingCustomFrame = !isDrawingCustomFrame;
	id window = [[[NSApplication sharedApplication] windows] objectAtIndex:0];
	[[[window contentView] superview] setNeedsDisplay:YES];
}


- (void)drawRect:(NSRect)rect
{
	// Call original drawing method
	[self drawRectOriginal:rect];

	if (!isDrawingCustomFrame)	return;

	//
	// Build clipping path : intersection of frame clip (bezier path with rounded corners) and rect argument
	//
	NSRect windowRect = [[self window] frame];
	windowRect.origin = NSMakePoint(0, 0);

	float cornerRadius = [self roundedCornerRadius];
	[[NSBezierPath bezierPathWithRoundedRect:windowRect xRadius:cornerRadius yRadius:cornerRadius] addClip];
	[[NSBezierPath bezierPathWithRect:rect] addClip];

	//
	// Draw background image (extend drawing rect : biggest rect dimension become's rect size)
	//
	NSRect imageRect = windowRect;
	if (imageRect.size.width > imageRect.size.height)
	{
		imageRect.origin.y = -(imageRect.size.width-imageRect.size.height)/2;
		imageRect.size.height = imageRect.size.width;
	}
	else
	{
		imageRect.origin.x = -(imageRect.size.height-imageRect.size.width)/2;
		imageRect.size.width = imageRect.size.height;
	}
	[[NSImage imageNamed:NSImageNameActionTemplate] drawInRect:imageRect fromRect:NSZeroRect operation:NSCompositeSourceAtop fraction:0.15];

	//
	// Draw a background color on top of everything
	//
	CGContextRef context = [[NSGraphicsContext currentContext]graphicsPort];
	CGContextSetBlendMode(context, kCGBlendModeColorDodge);
	[[NSColor colorWithCalibratedRed:0.7 green:0.4 blue:0 alpha:0.4] set];
	[[NSBezierPath bezierPathWithRect:rect] fill];
}
@end
