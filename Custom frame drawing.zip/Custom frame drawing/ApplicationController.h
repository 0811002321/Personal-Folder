//
//  ApplicationController.h
//  Custom frame drawing
//
//  Created by Patrick Geiller on 13/03/09.
//  Copyright 2009 __MyCompanyName__. All rights reserved.
//

#import <Cocoa/Cocoa.h>


@interface ApplicationController : NSObject {

}


- (IBAction)toggleDrawing:(id)sender;

@end
